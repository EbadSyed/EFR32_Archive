#include "em_device.h"
#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "i2cspm.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include "retargetswo.h"
#include "stddef.h"

#define St_LED_port gpioPortA
#define St_1_LED_pin 0
#define St_2_LED_pin 1
#define St_3_LED_pin 2

#define TCA6424A_ADDR 0x80

#define TCA6424A_CONFIGPORT_0 0x8C
#define TCA6424A_CONFIGPORT_1 0x8D
#define TCA6424A_CONFIGPORT_2 0x8E

#define TCA6424A_OPPORT_0 0x84
#define TCA6424A_OPPORT_1 0x85
#define TCA6424A_OPPORT_2 0x86

#define I2CSPM_INIT_DEFAULT_1                                              \
  { I2C0,                      /* Use I2C instance 0 */                       \
    gpioPortD,                 /* SCL port */                                 \
    15,                        /* SCL pin */                                  \
    gpioPortD,                 /* SDA port */                                 \
    14,                        /* SDA pin */                                  \
    22,                        /* Location of SCL */                          \
    22,                        /* Location of SDA */                          \
    0,                         /* Use currently configured reference clock */ \
    I2C_FREQ_STANDARD_MAX,     /* Set to standard rate  */                    \
    i2cClockHLRStandard,       /* Set to use 4:4 low/high duty cycle */       \
  }

#define I2CSPM_TRANSFER_TIMEOUT 300000


bool I2C_detect1(I2C_TypeDef *i2c, uint8_t addr)
{
	//printf("..............1..............\n");
  I2C_TransferSeq_TypeDef    seq;
  I2C_TransferReturn_TypeDef I2C_Status;
  uint8_t                    i2c_write_data[1];

  uint8_t reg = 0x04;
  seq.addr  = addr;
  seq.flags = I2C_FLAG_WRITE;
  i2c_write_data[0] = addr;
  seq.buf[0].data   = &reg ;
  seq.buf[0].len    = sizeof(addr);
  seq.buf[1].len    = 0;
  I2C_Status = I2C_TransferInit(I2C0, &seq);

 // printf("..............2..............\n");
   while (I2C_Status == i2cTransferInProgress)
   {
	//   printf("..............3..............\n");
	   I2C_Status = I2C_Transfer(I2C0);
	 //  printf("..............4..............\n");
  }
  // printf("..............5..............\n");
  if (I2C_Status != i2cTransferDone) {
	printf("non detector, we have return value :%d\n\r",I2C_Status);
    return false;
  }
  printf("detect!\n\r");
  printf("\n");
  printf("\n");
  for(volatile long i=0; i<5000000; i++);

  return true;
}

void TCA6424A_write_output(uint16_t port)
{
	I2C_TransferSeq_TypeDef    seq;
	I2C_TransferReturn_TypeDef I2C_Status;

	uint8_t reg = port;
	uint8_t out = 0x00;
	seq.addr  = 68;
	seq.flags = I2C_FLAG_WRITE_WRITE;
	seq.buf[0].data   = &reg ;
	seq.buf[0].len    = 1;
	seq.buf[1].data   = &out ;
	seq.buf[1].len    = 1;

	I2C_Status = I2C_TransferInit(I2C0, &seq);

    while (I2C_Status == i2cTransferInProgress)
    {
      I2C_Status = I2C_Transfer(I2C0);
    }

    printf("I2C Status %d \n \n",I2C_Status);


}

void TCA6424A_write_bank(uint16_t port)
{
	I2C_TransferSeq_TypeDef    seq;
	I2C_TransferReturn_TypeDef I2C_Status;

	uint8_t reg = 0x04 + port;
	uint8_t out = 0xff;
	seq.addr  = 68;
	seq.flags = I2C_FLAG_WRITE_WRITE;
	seq.buf[0].data   = &reg ;
	seq.buf[0].len    = 1;
	seq.buf[1].data   = &out ;
	seq.buf[1].len    = 2;

	I2C_Status = I2C_TransferInit(I2C0, &seq);

    while (I2C_Status == i2cTransferInProgress)
    {
      I2C_Status = I2C_Transfer(I2C0);
    }

    printf("I2C Status %d \n \n",I2C_Status);


}


void TCA6424A_write_led(uint16_t port,uint16_t value)
{
	I2C_TransferSeq_TypeDef    seq;
	I2C_TransferReturn_TypeDef I2C_Status;

	uint8_t reg = port;
	uint8_t out = value;
	seq.addr  = 68;
	seq.flags = I2C_FLAG_WRITE_WRITE;
	seq.buf[0].data   = &reg ;
	seq.buf[0].len    = 1;
	seq.buf[1].data   = &out ;
	seq.buf[1].len    = 1;

	I2C_Status = I2C_TransferInit(I2C0, &seq);

    while (I2C_Status == i2cTransferInProgress)
    {
      I2C_Status = I2C_Transfer(I2C0);
    }

    printf("I2C Status %d \n \n",I2C_Status);


}

int main(void)
{
	RETARGET_SwoInit();



    I2CSPM_Init_TypeDef i2cInit = I2CSPM_INIT_DEFAULT_1;

    /* Chip errata */
    CHIP_Init();

    //CMU_ClockEnable(cmuClock_USART0, true);
    CMU_ClockEnable(cmuClock_GPIO, true);
    CMU_ClockEnable(cmuClock_I2C0, true);
    CMU_ClockEnable(cmuClock_CORELE, true);
    CMU_OscillatorEnable(cmuOsc_LFXO, true, true);

    GPIO_PinModeSet(gpioPortC, 11, gpioModePushPull, 1);
    GPIO_PinModeSet(gpioPortA, 4, gpioModeInput, 0);
    GPIO_PinModeSet(gpioPortA, 5, gpioModeInput, 0);

  /* Pin PD14 is configured to Open-drain with pull-up and filter */
    GPIO_PinModeSet(gpioPortD, 14, gpioModeWiredAnd, 1);
  	//GPIO_PinModeSet(gpioPortD, 14, gpioModeWiredAnd, 1);

  	/* Pin PD15 is configured to Open-drain with pull-up and filter */
    GPIO_PinModeSet(gpioPortD, 15, gpioModeWiredAnd, 1);
  	//GPIO_PinModeSet(gpioPortD, 15, gpioModeWiredAnd, 1);

    GPIO_PinModeSet(gpioPortC, 11, gpioModePushPull, 1);
    GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 0);

    I2CSPM_Init(&i2cInit);

    for(volatile long i=0; i<2000000; i++);
    GPIO_PinModeSet(gpioPortA, 2, gpioModePushPull, 1);
    GPIO_PinModeSet(gpioPortF, 4, gpioModePushPull, 0);




    GPIO_PinModeSet(gpioPortB, 11, gpioModePushPull, 1);

    GPIO_PinModeSet(gpioPortB, 12, gpioModePushPull, 1);
    GPIO_PinModeSet(gpioPortF, 5, gpioModePushPull, 1);
    GPIO_PinModeSet(gpioPortF, 6, gpioModePushPull, 1);
    GPIO_PinModeSet(gpioPortF, 7, gpioModePushPull, 1);




//    TCA6424A_write_bank(0);

//    for(volatile long i=0; i<20000000; i++);

    TCA6424A_write_output(TCA6424A_CONFIGPORT_0);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x00);
    TCA6424A_write_output(TCA6424A_CONFIGPORT_1);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x00);
    TCA6424A_write_output(TCA6424A_CONFIGPORT_2);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x00);
/*

    TCA6424A_write_led(TCA6424A_OPPORT_1,0xb4);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x01);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x0f);
*/



    TCA6424A_write_led(TCA6424A_OPPORT_0,0x00);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x01);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x03);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x07);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x0F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x1F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x3F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0x7F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_0,0xFF);


    //TCA6424A_write_output(TCA6424A_CONFIGPORT_1);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x00);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x01);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x03);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x07);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x0F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x1F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x3F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0x7F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_1,0xFF);



    //TCA6424A_write_output(TCA6424A_CONFIGPORT_2);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x00);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x01);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x03);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x07);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x0F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x1F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x3F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0x7F);
    for(volatile long i=0; i<2000000; i++);
    TCA6424A_write_led(TCA6424A_OPPORT_2,0xFF);




}
