#include "em_device.h"
#include "em_chip.h"
#include "em_cmu.h"
#include "em_gpio.h"
#include "i2cspm.h"
#include "si7013.h"
#include "bspconfig.h"
#include <stdio.h>
#include <stdarg.h>
#include "InitDevice.h"
#include "bsp.h"
#include "PCA9685.h"

#define St_LED_port gpioPortF
#define St_1_LED_pin 4
#define St_2_LED_pin 5


void initI2C(void)
{
  // Using default settings
  I2C_Init_TypeDef i2cInit = I2C_INIT_DEFAULT;
  // Use ~400khz SCK
  i2cInit.freq = I2C_FREQ_STANDARD_MAX ;

  // Using PC10 (SDA) and PC11 (SCL)
  GPIO_PinModeSet(gpioPortC, 10, gpioModeWiredAndPullUpFilter, 1);
  GPIO_PinModeSet(gpioPortC, 11, gpioModeWiredAndPullUpFilter, 1);

  // Enable pins at location 15 as specified in datasheet
  I2C0->ROUTEPEN = I2C_ROUTEPEN_SDAPEN | I2C_ROUTEPEN_SCLPEN;
  I2C0->ROUTELOC0 = (I2C0->ROUTELOC0 & (~_I2C_ROUTELOC0_SDALOC_MASK)) | I2C_ROUTELOC0_SDALOC_LOC16;
  I2C0->ROUTELOC0 = (I2C0->ROUTELOC0 & (~_I2C_ROUTELOC0_SCLLOC_MASK)) | I2C_ROUTELOC0_SCLLOC_LOC14;

  // Initializing the I2C
  I2C_Init(I2C0, &i2cInit);

}


int main(void)
{

  /* Chip errata */
  CHIP_Init();

  RETARGET_SerialInit();
  CMU_ClockEnable(cmuClock_USART0, true);
  CMU_ClockEnable(cmuClock_GPIO, true);
  CMU_ClockEnable(cmuClock_I2C0, true);

  enter_DefaultMode_from_RESET();
  BSP_Init( BSP_INIT_BCC );

  I2C_Enable(I2C0, true);

  initI2C();


  //GPIO_PinModeSet(gpioPortB, 10, gpioModePushPull, 1);
  GPIO_PinModeSet(gpioPortA, 5, gpioModePushPull, 1);

  bool a = PCA9685_init();

  printf("doodoo \n");
  printf("Hello World %d \n",a);

  PCA9685_write(0,30000);
  PCA9685_write(7,20000);
  PCA9685_write(4,1655);
  PCA9685_write(5,4095);
  PCA9685_write(6,8000);

  printf("we did it hurray! \n");



  /* Get initial sensor status */
 // si7013_status = Si7013_Detect(i2cInit.port, SI7021_ADDR, 0);

  /* Infinite loop */
  while (1) {

	  	  GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 1);
	  	  GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 1);

	  	  for(volatile long i=0; i<100000; i++)
	  	              ;

	  	  GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 0);
	  	  GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 0);

	  	  for(volatile long i=0; i<100000; i++)
	  	              ;


  }
}

void Create_String(char string[], int32_t value)
{
  if (value < 0) {
    value = -value;
    string[0] = '-';
  } else {
    string[0] = ' ';
  }
  string[6] = 0;
  string[5] = '0' + (value % 100) / 10;
  string[4] = '0' + (value % 1000) / 100;
  string[3] = '.';
  string[2] = '0' + (value % 10000) / 1000;
  string[1] = '0' + (value % 100000) / 10000;

  if (string[1] == '0') {
    string[1] = ' ';
  }
}



/*
void send_string(char * string)
{
      while (*string != 0)
      {
            if (*string == '\n')
            {
                  USART_Tx(USART0, '\r');
            }
            USART_Tx(USART0, *string++);
      }
}

void print(const char* format, ...)
{
    char       msg[130];
    va_list    args;

    va_start(args, format);
    vsnprintf(msg, sizeof(msg), format, args); // do check return value
    va_end(args);

    send_string(msg);
}
*/
//void USART0_RX_IRQHandler(void)
//{
//      if (USART0->IF & USART_IF_RXDATAV)
//      {
//            char test_char = USART_Rx(USART0);
//      }
//}
