//#include "em_device.h"
//#include "em_chip.h"
//#include "em_cmu.h"
//#include "em_emu.h"
//#include "em_gpio.h"
//#include "i2cspm.h"
//#include <stdio.h>
//#include <stdarg.h>
//#include <stdbool.h>
//#include <stddef.h>
//#include "retargetswo.h"
//#include "stddef.h"
////#include "bspconfig.h"
////#include "bsp_1.h"
//
//
//#define St_LED_port gpioPortA
//#define St_1_LED_pin 0
//#define St_2_LED_pin 1
//#define St_3_LED_pin 2
//
//
///*
//#define TCA6424A_ADDRESS_ADDR_LOW   0x22 // address pin low (GND)
//#define TCA6424A_ADDRESS_ADDR_HIGH  0x23 // address pin high (VCC)
//#define TCA6424A_DEFAULT_ADDRESS    TCA6424A_ADDRESS_ADDR_LOW
//
//#define TCA6424A_RA_INPUT0          0x00
//#define TCA6424A_RA_INPUT1          0x01
//#define TCA6424A_RA_INPUT2          0x02
//#define TCA6424A_RA_OUTPUT0         0x04
//#define TCA6424A_RA_OUTPUT1         0x05
//#define TCA6424A_RA_OUTPUT2         0x06
//#define TCA6424A_RA_POLARITY0       0x08
//#define TCA6424A_RA_POLARITY1       0x09
//#define TCA6424A_RA_POLARITY2       0x0A
//#define TCA6424A_RA_CONFIG0         0x0C
//#define TCA6424A_RA_CONFIG1         0x0D
//#define TCA6424A_RA_CONFIG2         0x0E
//
//#define TCA6424A_AUTO_INCREMENT     0x80
//
//#define TCA6424A_LOW                0
//#define TCA6424A_HIGH               1
//
//#define TCA6424A_POLARITY_NORMAL    0
//#define TCA6424A_POLARITY_INVERTED  1
//
//#define TCA6424A_OUTPUT             0
//#define TCA6424A_INPUT              1
//
//#define TCA6424A_P00                0
//#define TCA6424A_P01                1
//#define TCA6424A_P02                2
//#define TCA6424A_P03                3
//#define TCA6424A_P04                4
//#define TCA6424A_P05                5
//#define TCA6424A_P06                6
//#define TCA6424A_P07                7
//#define TCA6424A_P10                8
//#define TCA6424A_P11                9
//#define TCA6424A_P12                10
//#define TCA6424A_P13                11
//#define TCA6424A_P14                12
//#define TCA6424A_P15                13
//#define TCA6424A_P16                14
//#define TCA6424A_P17                15
//#define TCA6424A_P20                16
//#define TCA6424A_P21                17
//#define TCA6424A_P22                18
//#define TCA6424A_P23                19
//#define TCA6424A_P24                20
//#define TCA6424A_P25                21
//#define TCA6424A_P26                22
//#define TCA6424A_P27                23
//
//*/
//#define I2CSPM_INIT_DEFAULT_1                                                 \
//  { I2C0,                      /* Use I2C instance 0 */                       \
//    gpioPortD,                 /* SCL port */                                 \
//    15,                        /* SCL pin */                                  \
//    gpioPortD,                 /* SDA port */                                 \
//    14,                        /* SDA pin */                                  \
//    22,                        /* Location of SCL */                          \
//    22,                        /* Location of SDA */                          \
//    0,                         /* Use currently configured reference clock */ \
//    I2C_FREQ_STANDARD_MAX,     /* Set to standard rate  */                    \
//    i2cClockHLRStandard,       /* Set to use 4:4 low/high duty cycle */       \
//  }
//
//#define I2CSPM_TRANSFER_TIMEOUT 300000
//
//
////bool led_driver_detect(void)
////{  uint8_t deviceId = 0;
////
////  printf("..............1..............\n");
////  I2C_TransferSeq_TypeDef    seq;
////  I2C_TransferReturn_TypeDef ret;
////  uint8_t                    i2c_read_data[1];
////  uint8_t                    i2c_write_data[2];
////
////  seq.addr  = TCA6424A_ADDRESS_ADDR_LOW;
////  seq.flags = I2C_FLAG_WRITE_READ;
////  /* Select command to issue */
////  i2c_write_data[0] = TCA6424A_RA_CONFIG0;
////  seq.buf[0].data   = i2c_write_data;
////  seq.buf[1].data   = TCA6424A_OUTPUT;
////  seq.buf[0].len    = 2;
////  /* Select location/length of data to be read */
////  seq.buf[1].data = i2c_read_data;
////  seq.buf[1].len  = 1;
////
////  printf("..............2..............\n");
////
////  ret = I2CSPM_Transfer(I2C0, &seq);
////  printf("ret= %d\n", ret);
////
////  printf("..............3..............\n");
////
////  if (ret != i2cTransferDone) {
////	  printf("..............4..............\n");
////    return false;
////  }
////  printf("..............5..............\n");
////
////  if (NULL != deviceId) {
////    deviceId = i2c_read_data[0];
////    printf("deviceID_1= %d\n", i2c_read_data[0]);
////  }
////  printf("deviceID_1= %d\n", i2c_read_data[0]);
////  return true;
////}
//
//bool I2C_detect1(I2C_TypeDef *i2c, uint8_t addr)
//{
//	printf("..............1..............\n");
//  I2C_TransferSeq_TypeDef    seq;
//  I2C_TransferReturn_TypeDef I2C_Status;
//  uint8_t                    i2c_write_data[1];
//
//  seq.addr  = addr;
//  seq.flags = I2C_FLAG_WRITE;
//  i2c_write_data[0] = addr;
//  seq.buf[0].data   = (uint8_t *)i2c_write_data;
//  seq.buf[0].len    = sizeof(addr);
//  seq.buf[1].len    = 0;
//  I2C_Status = I2C_TransferInit(I2C0, &seq);
//
//  printf("..............2..............\n");
//   while (I2C_Status == i2cTransferInProgress)
//   {
//	   I2C_Status = I2C_Transfer(I2C0);
//	   printf("..............3..............\n");
//  }
//
//   printf("..............4..............\n");
//  if (I2C_Status != i2cTransferDone) {
//	printf("non detector, we have return value :%d\n\r",I2C_Status);
//    return false;
//  }
//  printf("detect!\n\r");
//  printf("\n");
//  printf("\n");
//  for(volatile long i=0; i<5000000; i++);
//
//  return true;
//}
//
//
//void user_button_one(void)
//{
//		GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 1);
//		GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 1);
//		GPIO_PinModeSet(St_LED_port, St_3_LED_pin, gpioModePushPull, 1);
//
//		for(volatile long i=0; i<500000; i++);
//
//		GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 0);
//		GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 0);
//		GPIO_PinModeSet(St_LED_port, St_3_LED_pin, gpioModePushPull, 0);
//
//		for(volatile long i=0; i<500000; i++);
//}
//
//void user_button_two(void)
//{
//		GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 1);
//		GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 1);
//		GPIO_PinModeSet(St_LED_port, St_3_LED_pin, gpioModePushPull, 1);
//
//		for(volatile long i=0; i<100000; i++);
//
//		GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 0);
//		GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 0);
//		GPIO_PinModeSet(St_LED_port, St_3_LED_pin, gpioModePushPull, 0);
//
//		for(volatile long i=0; i<100000; i++);
//}
//
//
//int main(void)
//{
//	RETARGET_SwoInit();
//
//  //I2CSPM_Init_TypeDef i2cInit = I2CSPM_INIT_DEFAULT_1;
//	//I2C_Init_TypeDef i2cInit = I2C_INIT_DEFAULT;
//	I2C_Init_TypeDef i2cInit = I2CSPM_INIT_DEFAULT_1;
//
//  bool led_driver_status;
//
//  /* Chip errata */
//  CHIP_Init();
//
//  //CMU_ClockEnable(cmuClock_USART0, true);
//  CMU_ClockEnable(cmuClock_GPIO, true);
//  CMU_ClockEnable(cmuClock_I2C0, true);
//  CMU_ClockEnable(cmuClock_CORELE, true);
//  CMU_OscillatorEnable(cmuOsc_LFXO, true, true);
//
//  GPIO_PinModeSet(gpioPortA, 4, gpioModeInput, 0);
//  GPIO_PinModeSet(gpioPortA, 5, gpioModeInput, 0);
//
//  /* Pin PD14 is configured to Open-drain with pull-up and filter */
//  	GPIO_PinModeSet(gpioPortD, 14, gpioModeWiredAndPullUpFilter, 1); //SDA
//
//  	/* Pin PD15 is configured to Open-drain with pull-up and filter */
//  	GPIO_PinModeSet(gpioPortD, 15, gpioModeWiredAndPullUpFilter, 1); //SCL
//
//  	GPIO_PinModeSet(gpioPortC, 11, gpioModePushPull, 1);
//
//
//
//  for(volatile long i=0; i<10000000; i++);
//  //I2CSPM_Init(&i2cInit);
//  // Initializing the I2C
//    I2C_Init(I2C0, &i2cInit);
//
//  // Enable pins at location 15 as specified in datasheet
//    I2C0->ROUTEPEN = I2C_ROUTEPEN_SDAPEN | I2C_ROUTEPEN_SCLPEN;
//    I2C0->ROUTELOC0 = (I2C0->ROUTELOC0 & (~_I2C_ROUTELOC0_SDALOC_MASK)) | I2C_ROUTELOC0_SDALOC_LOC22;
//    I2C0->ROUTELOC0 = (I2C0->ROUTELOC0 & (~_I2C_ROUTELOC0_SCLLOC_MASK)) | I2C_ROUTELOC0_SCLLOC_LOC22;
//
//
////  int bb = I2C0->STATE;
////  int cc = I2C_STATE_BUSY;
////  printf("bb= %d", bb);
////  printf("    cc= %d\n", cc);
////  if (I2C0->STATE & I2C_STATE_BUSY)
////       {
////  	  I2C0->CMD = I2C_CMD_ABORT;
////       }
////
////	 bb = I2C0->STATE;
////	 cc = I2C_STATE_BUSY;
////	    printf("bb= %d", bb);
////	    printf("    cc= %d\n", cc);
//
//	    printf("*---------------Begin---------------*\n");
//
//  /* Infinite loop */
//  while (1) {
//
//
//	  //led_driver_status = led_driver_detect();
//
//	  //printf("Status: ");
//	  //printf("%s", led_driver_status ? "true" : "false");
//	  //printf("\n");
//
//	  bool live_button_state_1 = GPIO_PinInGet(gpioPortA, 4);
//
//	  	  if (live_button_state_1 == 0)
//	  	          {
//	  		  	  	  user_button_one();
//	  	          }
//
//	  	bool live_button_state_2 = GPIO_PinInGet(gpioPortA, 5);
//
//	  		  if (live_button_state_2 == 0)
//	  		          {
//	  			  	  	  user_button_two();
//	  		          }
//
//	  bool             sensor_status;
//	  int32_t address;
//
//	  for(address = 0; address < 127; address++ )
//	  	    {
//	  		  printf("      Address: ");
//	  		  printf("%d", address);
//	  		  printf("\n");
////
////	  	  sensor_status = I2C_detect1(i2cInit.port, address, 0);
//	  	  sensor_status = I2C_detect1(I2C0, address);
////
////
//	  	  printf("      Status: ");
//	  	  printf("%s", sensor_status ? "true" : "false");
//
////
//	  	  printf("\n");
//		  for(volatile long i=0; i<90000; i++);
////
////
//	  	  printf("\n");
//
//	    }
//
//	  		//printf("Hello World\n");
//
//	  for(volatile long i=0; i<500000; i++);
//
//
//
//
////	  GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 1);
////	  GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 1);
////	  GPIO_PinModeSet(St_LED_port, St_3_LED_pin, gpioModePushPull, 1);
////	  GPIO_PinModeSet(gpioPortB, 11, gpioModePushPull, 1);
////	  GPIO_PinModeSet(gpioPortB, 12, gpioModePushPull, 1);
////	  GPIO_PinModeSet(gpioPortF, 5, gpioModePushPull, 1);
////	  GPIO_PinModeSet(gpioPortF, 6, gpioModePushPull, 1);
////	  GPIO_PinModeSet(gpioPortF, 7, gpioModePushPull, 1);
////	  //printf("Testing... \n");
////
////
////	  for(volatile long i=0; i<500000; i++);
////
////	  GPIO_PinModeSet(St_LED_port, St_1_LED_pin, gpioModePushPull, 0);
////	  GPIO_PinModeSet(St_LED_port, St_2_LED_pin, gpioModePushPull, 0);
////	  GPIO_PinModeSet(St_LED_port, St_3_LED_pin, gpioModePushPull, 0);
////	  GPIO_PinModeSet(gpioPortB, 11, gpioModePushPull, 0);
////	  GPIO_PinModeSet(gpioPortB, 12, gpioModePushPull, 0);
////	  GPIO_PinModeSet(gpioPortF, 5, gpioModePushPull, 0);
////	  GPIO_PinModeSet(gpioPortF, 6, gpioModePushPull, 0);
////	  GPIO_PinModeSet(gpioPortF, 7, gpioModePushPull, 0);
//
//	  //for(volatile long i=0; i<500000; i++);
//
//  }}


#include "em_device.h"
#include "em_chip.h"
#include "em_cmu.h"
#include "em_emu.h"
#include "em_gpio.h"
#include "i2cspm.h"
#include <stdio.h>
#include <stdarg.h>
#include <stdbool.h>
#include <stddef.h>
#include "retargetswo.h"
#include "stddef.h"

#define St_LED_port gpioPortA
#define St_1_LED_pin 0
#define St_2_LED_pin 1
#define St_3_LED_pin 2


#define I2CSPM_INIT_DEFAULT_1                                              \
  { I2C0,                      /* Use I2C instance 0 */                       \
    gpioPortD,                 /* SCL port */                                 \
    15,                        /* SCL pin */                                  \
    gpioPortD,                 /* SDA port */                                 \
    14,                        /* SDA pin */                                  \
    22,                        /* Location of SCL */                          \
    22,                        /* Location of SDA */                          \
    0,                         /* Use currently configured reference clock */ \
    I2C_FREQ_STANDARD_MAX,     /* Set to standard rate  */                    \
    i2cClockHLRStandard,       /* Set to use 4:4 low/high duty cycle */       \
  }

#define I2CSPM_TRANSFER_TIMEOUT 300000


bool I2C_detect1(I2C_TypeDef *i2c, uint8_t addr)
{
	//printf("..............1..............\n");
  I2C_TransferSeq_TypeDef    seq;
  I2C_TransferReturn_TypeDef I2C_Status;
  uint8_t                    i2c_write_data[1];

  seq.addr  = addr;
  seq.flags = I2C_FLAG_WRITE;
  i2c_write_data[0] = addr;
  seq.buf[0].data   = (uint8_t *)i2c_write_data;
  seq.buf[0].len    = sizeof(addr);
  seq.buf[1].len    = 0;
  I2C_Status = I2C_TransferInit(I2C0, &seq);

 // printf("..............2..............\n");
   while (I2C_Status == i2cTransferInProgress)
   {
	//   printf("..............3..............\n");
	   I2C_Status = I2C_Transfer(I2C0);
	 //  printf("..............4..............\n");
  }
  // printf("..............5..............\n");
  if (I2C_Status != i2cTransferDone) {
	printf("non detector, we have return value :%d\n\r",I2C_Status);
    return false;
  }
  printf("detect!\n\r");
  printf("\n");
  printf("\n");
  for(volatile long i=0; i<5000000; i++);

  return true;
}

int main(void)
{
	RETARGET_SwoInit();



  I2CSPM_Init_TypeDef i2cInit = I2CSPM_INIT_DEFAULT;

  //bool led_driver_status;

  /* Chip errata */
  CHIP_Init();

  //CMU_ClockEnable(cmuClock_USART0, true);
  CMU_ClockEnable(cmuClock_GPIO, true);
  CMU_ClockEnable(cmuClock_I2C0, true);
  CMU_ClockEnable(cmuClock_CORELE, true);
  CMU_OscillatorEnable(cmuOsc_LFXO, true, true);


  GPIO_PinModeSet(gpioPortA, 4, gpioModeInput, 0);
  GPIO_PinModeSet(gpioPortA, 5, gpioModeInput, 0);

  /* Pin PD14 is configured to Open-drain with pull-up and filter */
  	GPIO_PinModeSet(gpioPortD, 14, gpioModeWiredAnd, 1);
  	//GPIO_PinModeSet(gpioPortD, 14, gpioModeWiredAnd, 1);

  	/* Pin PD15 is configured to Open-drain with pull-up and filter */
  	GPIO_PinModeSet(gpioPortD, 15, gpioModeWiredAnd, 1);
  	//GPIO_PinModeSet(gpioPortD, 15, gpioModeWiredAnd, 1);

  GPIO_PinModeSet(gpioPortC, 11, gpioModePushPull, 1);
  GPIO_PinModeSet(gpioPortC, 10, gpioModePushPull, 0);

  I2CSPM_Init(&i2cInit);

  for(volatile long i=0; i<2000000; i++);
  GPIO_PinModeSet(gpioPortA, 2, gpioModePushPull, 1);
  GPIO_PinModeSet(gpioPortF, 4, gpioModePushPull, 0);

  /* Infinite loop */
  while (1) {

	  printf("---------------Begin---------------\n");
	  bool             sensor_status;
	  int32_t address;
	  //int address;

	  for(address = 0; address < 256; address++ )
	  	    {
		  GPIO_PinModeSet(gpioPortA, 1, gpioModePushPull, 1);
	  		  printf("      Address: ");
	  		  printf("%d", address);
	  		  printf("\n");


	  	  sensor_status = I2C_detect1(I2C0, address);

	  	  printf("      Status: %d ==> ",sensor_status);
	  	  printf("%s", sensor_status ? "true" : "false");

	  	  printf("\n");

	  	  printf("\n");
	  	for(volatile long i=0; i<70000; i++);
	  	GPIO_PinModeSet(gpioPortA, 1, gpioModePushPull, 0);
	  	for(volatile long i=0; i<70000; i++);
	    }
	  GPIO_PinModeSet(gpioPortA, 0, gpioModePushPull, 1);
	  for(volatile long i=0; i<1000000; i++);
	  GPIO_PinModeSet(gpioPortF, 4, gpioModePushPull, 1);
	  GPIO_PinModeSet(gpioPortA, 0, gpioModePushPull, 0);

  }
}
